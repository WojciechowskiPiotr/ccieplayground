//
//  ViewController.swift
//  ASAManagement
//
//  Created by peper on 10/01/2017.
//  Copyright © 2017 Piotr Wojciechowski. All rights reserved.
//

import UIKit
import Foundation
import Alamofire


class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var ProvideIPAddressLabel: UILabel!
    @IBOutlet weak var IPAddressTextField: UITextField!
    @IBOutlet weak var OutputLabel: UILabel!
    
    
    
    // Preferred status bar style lightContent to use on dark background.
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        IPAddressTextField.delegate = self
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITextField delegates
    
    // Functiuon is called after the text field resigns its first-responder status
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    // Function is called when user taps Return
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide keyboard
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: My func's
    
    // Checking version executed when button is pressed
    @IBAction func CheckVersion(_ sender: UIButton) {
        // Check if anything is in TextField box
        guard let text = IPAddressTextField.text, !text.isEmpty else {
            let Alert = UIAlertController(title: "Alert!", message: "No hostname address provided", preferredStyle: UIAlertControllerStyle.alert)
            Alert.addAction(UIAlertAction(title: "Return", style: UIAlertActionStyle.default, handler: nil))
            self.present(Alert , animated: true, completion: nil)
            return
        }
        
        // Validate if IP address
        guard isNotValidIP(s: IPAddressTextField.text!) else {
            let Alert = UIAlertController(title: "Alert!", message: "Hostname is required, IP address is not allowed", preferredStyle: UIAlertControllerStyle.alert)
            Alert.addAction(UIAlertAction(title: "Return", style: UIAlertActionStyle.default, handler: nil))
            self.present(Alert , animated: true, completion: nil)
            return
        }
        
        
        let hostRef = CFHostCreateWithName(nil, IPAddressTextField.text as! CFString).takeRetainedValue()
        debugPrint(CFHostStartInfoResolution(hostRef, .addresses, nil))
        guard CFHostStartInfoResolution(hostRef, .addresses, nil) else {
            let Alert = UIAlertController(title: "Alert!", message: "DNS resolution of host failed", preferredStyle: UIAlertControllerStyle.alert)
            Alert.addAction(UIAlertAction(title: "Return", style: UIAlertActionStyle.default, handler: nil))
            self.present(Alert , animated: true, completion: nil)
            return
        }
        
        // Exec GET method for ASA firmware version
        // using Alamofire library
        self.OutputLabel.isHidden = true
        
        let credential = URLCredential(user: "cisco", password: "cisco", persistence: .forSession)
        let APIMethodURI = "https://" + IPAddressTextField.text! + "/api/monitoring/device/components/version"
        Alamofire.request(APIMethodURI).authenticate(usingCredential: credential).responseJSON { response in
            print("------ ERROR -----")
            debugPrint(response)
            print("---------")
            if let JSONResponse = response.result.value as? [String: Any] {
                print("JSON: \(JSONResponse)")
                print("\n\n\n")
                
                self.OutputLabel.text = "ASA firmware version: " + (JSONResponse["asaVersion"] as! String)
                self.OutputLabel.isHidden = false
                
            } else {
                
                self.OutputLabel.text = "No information from firewall or other error"
                self.OutputLabel.isHidden = false
            }
        }
        
    }
    
    
    // Verify if address is not valid IPv4
    private func isNotValidIP(s: String) -> Bool {
        let parts = s.components(separatedBy: ".")
        let nums = parts.flatMap { Int($0) }
        return !(parts.count == 4 && nums.count == 4 && nums.filter { $0 >= 0 && $0 < 256}.count == 4)
    }
    
    
    
    //MARK: End of code
    
}

